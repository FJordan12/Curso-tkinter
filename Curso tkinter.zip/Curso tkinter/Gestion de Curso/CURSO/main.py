class Curso:
    def __init__(self, nombre):
        self.nombre = nombre
        self.profesores = []
        self.estudiantes = []
        self.asignaturas = []
        self.evaluaciones = []
        self.horarios = []

class Profesor:
    def __init__(self, nombre):
        self.nombre = nombre

class Estudiante:
    def __init__(self, nombre):
        self.nombre = nombre

class Asignatura:
    def __init__(self, nombre):
        self.nombre = nombre

class Evaluacion:
    def __init__(self, nombre):
        self.nombre = nombre

class Horario:
    def __init__(self, dia, hora):
        self.dia = dia
        self.hora = hora

def main():
    cursos = []
    while True:
        print("1. Crear curso")
        print("2. Listar cursos")
        print("3. Salir")
        opcion = input("Seleccione una opción: ")
        if opcion == "1":
            nombre = input("Ingrese el nombre del curso: ")
            curso = Curso(nombre)
            cursos.append(curso)
        elif opcion == "2":
            for curso in cursos:
                print(curso.nombre)
        elif opcion == "3":
            break
        else:
            print("Opción no válida. Intente de nuevo.")

if __name__ == "__main__":
    main()
