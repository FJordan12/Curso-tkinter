class Evaluacion:
    def __init__(self, estudiante, asignatura, nota):
        self.estudiante = estudiante
        self.asignatura = asignatura
        self.nota = nota