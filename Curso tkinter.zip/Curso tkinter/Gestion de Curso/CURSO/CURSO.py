class Curso:
    def __init__(self, nombre, profesor, asignaturas, horario):
        self.nombre = nombre
        self.profesor = profesor
        self.asignaturas = asignaturas
        self.horario = horario
